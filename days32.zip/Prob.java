package days32;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Vector;

public class Prob extends Score {
	String line = "";
	String[] v = new String[5];
	Vector<Score> vv = new Vector<Score>();
	
	public Vector getScore(String fileName) throws Exception, FileNotFoundException {
		BufferedReader bf = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));
		Score sc = new Score();
		while(true) {
			line = bf.readLine();
			if(line == null) {
				break;
			}
			v = line.split("/");
			/*
			sc.setName(v[0]);
			sc.setKor(Integer.parseInt(v[1]));
			sc.setEng(Integer.parseInt(v[2]));
			sc.setMath(Integer.parseInt(v[3]));
			sc.setSum(Integer.parseInt(v[1])+Integer.parseInt(v[2])+Integer.parseInt(v[3]));
			*/
			int sum = Integer.parseInt(v[1])+Integer.parseInt(v[2])+Integer.parseInt(v[3]);
			sc = new Score(v[0],Integer.parseInt(v[1]),Integer.parseInt(v[2]),Integer.parseInt(v[3]),sum);
			vv.addElement(sc);
		}
		bf.close();
		return vv;
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Prob p2 = new Prob();
		Vector scores = p2.getScore("C:\\Users\\YOON\\eclipse-workspace\\practice\\JavaClass\\data.txt");
		for(int i = 0; i<scores.size();i++) {
			Score score = (Score)scores.get(i);
			System.out.println(score.getName()+" : "+score.getKor()+" "+score.getEng()+" "+score.getMath()+" "+score.getSum());
		}
	}

}
